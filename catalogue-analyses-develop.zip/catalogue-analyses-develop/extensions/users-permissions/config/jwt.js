module.exports = {
  jwtSecret: process.env.JWT_SECRET || '689836a4-963a-40eb-ad40-419a55e31817'
};