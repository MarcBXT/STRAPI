

const dateFormats = {
  time: 'HH:mm',
  date: 'DD/MM/YYYY',
  datetime: 'DD/MM/YYYY HH:mm',
  timestamp: 'DD/MM/YYYY HH:mm',
};

export default dateFormats;
