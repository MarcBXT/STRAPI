# Strapi plugin manage-catalog

A quick description of manage-catalog.
