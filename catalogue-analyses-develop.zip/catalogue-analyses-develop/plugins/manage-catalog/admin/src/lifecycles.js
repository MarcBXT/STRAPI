function lifecycles() {}

export default lifecycles;
