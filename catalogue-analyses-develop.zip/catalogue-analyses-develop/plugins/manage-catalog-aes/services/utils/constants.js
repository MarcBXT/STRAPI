const rootDir = process.cwd();

const TYPE_IMPORT = "AES";

const PATHS = {
  UPLOAD_REP: rootDir + "/public/uploads"
};

module.exports = { 
  TYPE_IMPORT,
  PATHS
};