# Strapi plugin manage-catalog-aes

A quick description of manage-catalog-aes.
