# Strapi plugin manage-catalog-cns

A quick description of manage-catalog-cns.
